	<script src="/assets/jquery-3.3.1.min.js"></script>
	<script src="/assets/script.js"></script>
</body>
</html>