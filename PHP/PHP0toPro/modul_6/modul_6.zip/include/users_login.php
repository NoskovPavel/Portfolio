<?php 
//массив логинов
$usersLogin = ['pavel',  'igor', 'sasha', 'nikolay', 'semen'];