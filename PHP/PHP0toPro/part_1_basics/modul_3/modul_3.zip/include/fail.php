<div style="color: red; font-size: 120%;">
	Неверный логин или пароль!
</div>