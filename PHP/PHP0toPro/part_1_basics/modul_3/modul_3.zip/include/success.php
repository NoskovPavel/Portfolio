<div style="color: red; font-size: 120%;">
	Вы успешно авторизованы!
</div>