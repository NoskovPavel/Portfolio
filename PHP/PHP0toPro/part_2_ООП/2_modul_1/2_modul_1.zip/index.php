<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
?>
<h1>
	<a href="/homeZoo/index.php">Домашний зоопарк</a>
</h1>
</br>
<h1>
	<a href="/hungryCat/index.php">Голодный кот</a>
</h1>
</br>
<h1>
	<a href="/toyFactory/index.php">Фабрика игрушек</a>
</h1>
</br>
<h1>
	<a href="/notice/index.php">Уведомления для клиента</a>
</h1>
</br>
<h1>
	<a href="/eshop/index.php">Интернет магазин</a>
</h1>