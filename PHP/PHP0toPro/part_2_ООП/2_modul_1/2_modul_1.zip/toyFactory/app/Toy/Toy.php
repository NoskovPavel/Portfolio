<?php

namespace toyFactory\app\Toy;

class Toy
{
	public $name;
	public $price;

	public function __construct($name, $price)
	{
		$this->name  = $name;
		$this->price = $price;
	}
}