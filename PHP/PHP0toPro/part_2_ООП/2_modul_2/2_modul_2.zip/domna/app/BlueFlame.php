<?php

namespace Domna\App;

class BlueFlame
{
    public function render($name)
    {
        return $name . " горит синим пламенем!</br>";
    }
}



