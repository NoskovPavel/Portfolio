<?php

namespace Domna\App;

interface Flared
{
    public function burn();

    public function __toString();
}



