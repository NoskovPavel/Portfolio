<?php

namespace Domna\App;

class RedFlame
{
    public function render($name)
    {
        return $name . " горит красным пламенем!</br>";
    }
}



