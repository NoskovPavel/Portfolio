<?php

namespace Domna\App;

class Smoke
{
    public function render($name)
    {
        return $name . " лишь задымился</br>";
    }
}



