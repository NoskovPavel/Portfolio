<?php

namespace Farm\App;

class Animal
{
    public function say()
    {
        echo '' . PHP_EOL;
    }
    public function walk()
    {
        echo 'топ-топ' . PHP_EOL;
    }
}
