<?php

namespace Farm2\App;

class Animal
{
    public function say()
    {
        echo '' . PHP_EOL;
    }
    public function walk()
    {
        echo '' . PHP_EOL;
    }
}



