<?php

namespace Farm2\App\Hoof\Hoofs;

use Farm2\App\Hoof\Hoof;

class Cow extends Hoof
{
    public function say()
    {
        echo 'Му!' . '</br>';
    }
}

