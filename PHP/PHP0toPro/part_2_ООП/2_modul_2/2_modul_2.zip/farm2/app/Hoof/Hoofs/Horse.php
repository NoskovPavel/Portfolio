<?php

namespace Farm2\App\Hoof\Hoofs;

use Farm2\App\Hoof\Hoof;

class Horse extends Hoof
{
    public function say()
    {
        echo 'Иго-го!' . '</br>';
    }
}

