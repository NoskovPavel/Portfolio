<?php

namespace Farm2\App\Hoof\Hoofs;

use Farm2\App\Hoof\Hoof;

class Pig extends Hoof
{
    public function say()
    {
        echo 'Хрю-хрю!' . '</br>';
    }
}

