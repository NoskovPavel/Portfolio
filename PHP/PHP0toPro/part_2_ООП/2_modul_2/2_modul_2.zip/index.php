<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
?>
<h1>
	<a href="/farm/index.php">Ферма</a>
</h1>
</br>
<h1>
	<a href="/farm2/index.php">Ферма 2.0</a>
</h1>
</br>
<h1>
	<a href="/blackBox/index.php">Черный ящик</a>
</h1>
</br>
<h1>
	<a href="/domna/index.php">Домна</a>
</h1>
